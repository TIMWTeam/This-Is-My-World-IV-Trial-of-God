# 炼狱附魔台
![炼狱附魔台](block:betterwithmods:infernal_enchanter)

炼狱附魔台是一个先进的附魔台，可以让你在附魔之前选择特定的附魔。
你需要一个有适当附魔属性的[奥术卷轴](../items/arcane_scrolls.md)和以炼狱附魔台为中心的17x17x17范围内的等同于附魔等级的书架。
炼狱附魔台需要比原版附魔台更多的经验，特别是如果你想在一个物品上附加多个附魔。

![](betterwithmods:docs/imgs/infernal_enchanter.png)
![](https://betterwithmods.github.io/Documentation/imgs/infernal_enchanter.png)
