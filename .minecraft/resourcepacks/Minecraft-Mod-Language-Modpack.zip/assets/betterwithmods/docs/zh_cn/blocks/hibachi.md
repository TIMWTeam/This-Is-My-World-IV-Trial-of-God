# 火盆

![火盆](block:betterwithmods:hibachi)

给予红石信号时，火盆会创建一个连续的火源。 只有火盆的火焰足以被[风箱](bellows.md)鼓风而不熄灭。
 
