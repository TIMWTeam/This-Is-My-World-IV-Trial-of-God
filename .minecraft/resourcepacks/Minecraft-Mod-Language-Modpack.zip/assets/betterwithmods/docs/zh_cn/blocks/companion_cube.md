# 伙伴方块

![伙伴方块](block:betterwithmods:companion_cube)

伙伴方块是通过将狼放在[方块放置回收器](block_dispenser.md)前面并激活它来获得的。

警告：在制作这个MOD时，只有少数数字动物会受到伤害。

