# 装饰方块

# 家具

## 木桌
![木桌](oredict:blockWoodTable)

## 木凳
![木凳](oredict:blockWoodBench)

## 板条栅栏
![板条栅栏](oredict:slats)

## 网格栅栏
![网格栅栏](oredict:grates)

## 筚板
![筚板](oredict:wicker)

## 铁墙
![铁墙](block:betterwithmods:iron_wall)
