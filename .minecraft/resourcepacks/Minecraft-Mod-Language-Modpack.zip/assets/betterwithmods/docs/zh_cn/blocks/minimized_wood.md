# 切割木料


![木半板](oredict:sidingWood) 
* 木半板 - 二分之一个方块。可以以任何方向放置。可以在许多合成表中用来代替完整的木板。

![木条](oredict:mouldingWood) 
* 木条 - 四分之一个方块。可以替代木棍，可以直接合成成木棍。

![木边角](oredict:cornerWood)
* 木边角 - 八分之一个方块。可以被[螺杆锯](saw.md)切割成[木齿轮](../items/gear.md)。
