# Dynamite

![Dynamite](item:betterwithmods:dynamite)

炸药是一种由 [爆破油膏](blasting_oil.md) 制成的爆炸物。 为了点燃它，你的物品栏之中需要有打火石。右键扔出。

提示: 你可以把它扔进水里面试试。 (如果“浮力”特性启用，效果最好。) 