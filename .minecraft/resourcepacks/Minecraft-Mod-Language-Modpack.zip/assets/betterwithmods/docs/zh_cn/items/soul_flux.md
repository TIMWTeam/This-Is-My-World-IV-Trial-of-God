# Soul Flux

![Soul Flux](item:betterwithmods:material@38)

Soul Flux is a bi-product of cooking [Ender Slag](ender_slag.md) in a [Stoked Cauldron](../blocks/cauldron.md).
It is a necessary product in the creation of [Soulforged Steel](soulforged_steel.md).