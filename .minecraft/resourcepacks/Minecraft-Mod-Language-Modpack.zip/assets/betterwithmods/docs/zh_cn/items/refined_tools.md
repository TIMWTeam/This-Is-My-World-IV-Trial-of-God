# Refined Tools

由 [熔魂钢](soulforged_steel.md) 和 [手柄](haft.md) 组成，在 [熔魂钢砧](../blocks/anvil.md) 上制作而成的工具，极其耐用。

熔魂钢斧
![Refined Axe](item:betterwithmods:steel_axe)

熔魂钢镐
![Refined Pickaxe](item:betterwithmods:steel_pickaxe)

熔魂钢铲
![Refined Shovel](item:betterwithmods:steel_shovel)

熔魂钢剑
![Refined Sword](item:betterwithmods:steel_sword)

熔魂钢锄
![Refined Hoe](item:betterwithmods:steel_hoe)

熔魂钢鹤嘴锄 - 结合了镐和铲的功能
![Refined Mattock](item:betterwithmods:steel_mattock)

熔魂钢战斧 - 结合了剑和斧的功能
![Refined Battleaxe](item:betterwithmods:steel_battleaxe)


