# Soap

![Soap](item:betterwithmods:material@50)

![Soap Block](block:betterwithmods:aesthetic@10)

肥皂可以用于清除诸如 [砧板](../blocks/chopping_block.md) 之类的东西上的污渍，也可以用于把粘性活塞变成普通活塞。

当然，可别把肥皂给掉了23333