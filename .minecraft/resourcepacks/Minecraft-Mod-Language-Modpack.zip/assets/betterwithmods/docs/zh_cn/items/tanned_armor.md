# Plate Armor

![Plate Helmet](item:betterwithmods:leather_tanned_helmet)
![Plate Chest](item:betterwithmods:leather_tanned_chest)
![Plate Leggings](item:betterwithmods:leather_tanned_pants)
![Plate Boots](item:betterwithmods:leather_tanned_boots)

