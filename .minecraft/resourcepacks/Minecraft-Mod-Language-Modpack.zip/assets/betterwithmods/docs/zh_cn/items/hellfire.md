# Hellfire 

![Hellfire Dust](item:betterwithmods:material@16)

你可以通过在 [漏斗](../blocks/hopper.md) 中过滤 [灵魂沙](../blocks/hopper_filters.md) 来获取炼狱火之烬。
