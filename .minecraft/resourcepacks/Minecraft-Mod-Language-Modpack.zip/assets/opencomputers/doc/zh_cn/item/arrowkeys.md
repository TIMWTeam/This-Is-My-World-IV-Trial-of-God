#方向键

![Just be grateful it's not made from arrows.](oredict:oc:materialArrowKey)

At the risk of repeating myself: 制造 [键盘](../block/keyboard.md)的配件.
