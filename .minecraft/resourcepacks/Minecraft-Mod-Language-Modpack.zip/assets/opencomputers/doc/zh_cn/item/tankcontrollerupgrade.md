# Tank Controller

![Fluid routing.](oredict:oc:tankControllerUpgrade)

储罐控制器可以控制储罐. 允许查询内部储罐和外部（比如岩浆发电机，UU机，BC罐子）.

可以被安放在 [适配器](../block/adapter.md),允许连接的[电脑](../general/computer.md)查询相邻的储罐信息

参见: [转置器](../block/transposer.md)
