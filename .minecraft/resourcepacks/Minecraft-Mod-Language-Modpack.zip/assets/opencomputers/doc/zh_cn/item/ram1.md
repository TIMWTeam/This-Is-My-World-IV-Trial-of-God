# Memory

![Do you remember, dancing in September~](oredict:oc:ram1)

内存和 [CPU](cpu1.md)一样都是[电脑](../general/computer.md)的核心部件. 根据 [CPU](cpu1.md)的架构, 内存决定了于电脑能做什么，不能做什么.以标准LUA为例, 内存条控制了脚本最大分配多少存储空间.这意味着你要安装更大的内存条跑更大的程序.

缺省状态下内存条的规格:
- T1: 192KB
- T1.5: 256KB 
- T2: 384KB
- T2.5: 512KB
- T3: 768KB
- T3.5: 1024KB

仅对LUA架构有效

此容量可以在配置修改