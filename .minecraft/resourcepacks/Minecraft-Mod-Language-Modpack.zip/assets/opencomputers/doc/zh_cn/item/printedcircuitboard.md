# Printed Circuit Board

![AKA PCB](oredict:oc:materialCircuitBoardPrinted)

电路板和 [晶体管](transistor.md)一样, 都是基础合成材料. 用于制作多种元件， [卡片](card.md) 和大量的[方块](../block/index.md).
