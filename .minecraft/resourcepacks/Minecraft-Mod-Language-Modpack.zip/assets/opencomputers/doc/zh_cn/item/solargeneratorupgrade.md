# Solar Generator

![Walking on the sun.](oredict:oc:solarGeneratorUpgrade)

太阳能发电机升级可以安装到[机器人](../block/robot.md), [无人机](drone.md) 和 [平板](tablet.md) 上面. 只会在阳光直射的时候工作; 设备被天气影响或者处于封闭空间时是不工作的，能量产生速度很慢