# Ink Cartridge

![The colors of the rainbow.](oredict:oc:inkCartridge)

墨盒为 [3D printers](../block/printer.md)供墨. 可以用染料来加满, 不过不是太方便. 