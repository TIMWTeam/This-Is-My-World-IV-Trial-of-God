# 机器

*机器分类*
- [发电机设备](machines/1-generators.md)
- [加工设备](machines/2-processing-machines.md)
- [运输设备](machines/3-transport.md)
- [实用设备](machines/4-utilities.md)
